// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ZCollections.pas' rev: 6.00

#ifndef ZCollectionsHPP
#define ZCollectionsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ZClasses.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Zcollections
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TZIterator;
class PASCALIMPLEMENTATION TZIterator : public Zclasses::TZAbstractObject 
{
	typedef Zclasses::TZAbstractObject inherited;
	
private:
	Zclasses::_di_IZCollection FCollection;
	int FCurrentIndex;
	
public:
	__fastcall TZIterator(const Zclasses::_di_IZCollection Col);
	bool __fastcall HasNext(void);
	System::_di_IInterface __fastcall Next();
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TZIterator(void) { }
	#pragma option pop
	
private:
	void *__IZIterator;	/* Zclasses::IZIterator */
	
public:
	operator IZIterator*(void) { return (IZIterator*)&__IZIterator; }
	
};


typedef System::_di_IInterface TZInterfaceList[134217727];

typedef System::_di_IInterface *PZInterfaceList;

class DELPHICLASS TZCollection;
class PASCALIMPLEMENTATION TZCollection : public Zclasses::TZAbstractObject 
{
	typedef Zclasses::TZAbstractObject inherited;
	
public:
	System::_di_IInterface operator[](int Index) { return Items[Index]; }
	
private:
	System::_di_IInterface *FList;
	int FCount;
	int FCapacity;
	
protected:
	/*         class method */ static void __fastcall Error(TMetaClass* vmt, const AnsiString Msg, int Data);
	void __fastcall Grow(void);
	void __fastcall SetCapacity(int NewCapacity);
	void __fastcall SetCount(int NewCount);
	
public:
	__fastcall TZCollection(void);
	__fastcall virtual ~TZCollection(void);
	virtual System::_di_IInterface __fastcall Clone();
	virtual AnsiString __fastcall ToString();
	System::_di_IInterface __fastcall Get(int Index);
	void __fastcall Put(int Index, const System::_di_IInterface Item);
	int __fastcall IndexOf(const System::_di_IInterface Item);
	int __fastcall GetCount(void);
	Zclasses::_di_IZIterator __fastcall GetIterator();
	System::_di_IInterface __fastcall First();
	System::_di_IInterface __fastcall Last();
	int __fastcall Add(const System::_di_IInterface Item);
	void __fastcall Insert(int Index, const System::_di_IInterface Item);
	int __fastcall Remove(const System::_di_IInterface Item);
	void __fastcall Exchange(int Index1, int Index2);
	void __fastcall Delete(int Index);
	void __fastcall Clear(void);
	bool __fastcall Contains(const System::_di_IInterface Item);
	bool __fastcall ContainsAll(const Zclasses::_di_IZCollection Col);
	bool __fastcall AddAll(const Zclasses::_di_IZCollection Col);
	bool __fastcall RemoveAll(const Zclasses::_di_IZCollection Col);
	__property int Count = {read=GetCount, nodefault};
	__property System::_di_IInterface Items[int Index] = {read=Get, write=Put/*, default*/};
private:
	void *__IZCollection;	/* Zclasses::IZCollection */
	
public:
	operator IZClonnable*(void) { return (IZClonnable*)&__IZCollection; }
	operator IZCollection*(void) { return (IZCollection*)&__IZCollection; }
	
};


class DELPHICLASS TZUnmodifiableCollection;
class PASCALIMPLEMENTATION TZUnmodifiableCollection : public Zclasses::TZAbstractObject 
{
	typedef Zclasses::TZAbstractObject inherited;
	
public:
	System::_di_IInterface operator[](int Index) { return Items[Index]; }
	
private:
	Zclasses::_di_IZCollection FCollection;
	void __fastcall RaiseException(void);
	
public:
	__fastcall TZUnmodifiableCollection(Zclasses::_di_IZCollection Collection);
	__fastcall virtual ~TZUnmodifiableCollection(void);
	virtual System::_di_IInterface __fastcall Clone();
	virtual AnsiString __fastcall ToString();
	System::_di_IInterface __fastcall Get(int Index);
	void __fastcall Put(int Index, const System::_di_IInterface Item);
	int __fastcall IndexOf(const System::_di_IInterface Item);
	int __fastcall GetCount(void);
	Zclasses::_di_IZIterator __fastcall GetIterator();
	System::_di_IInterface __fastcall First();
	System::_di_IInterface __fastcall Last();
	int __fastcall Add(const System::_di_IInterface Item);
	void __fastcall Insert(int Index, const System::_di_IInterface Item);
	int __fastcall Remove(const System::_di_IInterface Item);
	void __fastcall Exchange(int Index1, int Index2);
	void __fastcall Delete(int Index);
	void __fastcall Clear(void);
	bool __fastcall Contains(const System::_di_IInterface Item);
	bool __fastcall ContainsAll(const Zclasses::_di_IZCollection Col);
	bool __fastcall AddAll(const Zclasses::_di_IZCollection Col);
	bool __fastcall RemoveAll(const Zclasses::_di_IZCollection Col);
	__property int Count = {read=GetCount, nodefault};
	__property System::_di_IInterface Items[int Index] = {read=Get, write=Put/*, default*/};
private:
	void *__IZCollection;	/* Zclasses::IZCollection */
	
public:
	operator IZClonnable*(void) { return (IZClonnable*)&__IZCollection; }
	operator IZCollection*(void) { return (IZCollection*)&__IZCollection; }
	
};


class DELPHICLASS TZHashMap;
class PASCALIMPLEMENTATION TZHashMap : public Zclasses::TZAbstractObject 
{
	typedef Zclasses::TZAbstractObject inherited;
	
private:
	Zclasses::_di_IZCollection FKeys;
	Zclasses::_di_IZCollection FReadOnlyKeys;
	Zclasses::_di_IZCollection FValues;
	Zclasses::_di_IZCollection FReadOnlyValues;
	
public:
	__fastcall TZHashMap(void);
	__fastcall virtual ~TZHashMap(void);
	virtual System::_di_IInterface __fastcall Clone();
	System::_di_IInterface __fastcall Get(const System::_di_IInterface Key);
	void __fastcall Put(const System::_di_IInterface Key, const System::_di_IInterface Value);
	Zclasses::_di_IZCollection __fastcall GetKeys();
	Zclasses::_di_IZCollection __fastcall GetValues();
	int __fastcall GetCount(void);
	bool __fastcall Remove(System::_di_IInterface Key);
	void __fastcall Clear(void);
	__property int Count = {read=GetCount, nodefault};
	__property Zclasses::_di_IZCollection Keys = {read=GetKeys};
	__property Zclasses::_di_IZCollection Values = {read=GetValues};
private:
	void *__IZHashMap;	/* Zclasses::IZHashMap */
	
public:
	operator IZClonnable*(void) { return (IZClonnable*)&__IZHashMap; }
	operator IZHashMap*(void) { return (IZHashMap*)&__IZHashMap; }
	
};


class DELPHICLASS TZStack;
class PASCALIMPLEMENTATION TZStack : public Zclasses::TZAbstractObject 
{
	typedef Zclasses::TZAbstractObject inherited;
	
private:
	Zclasses::_di_IZCollection FValues;
	
public:
	__fastcall TZStack(void);
	__fastcall virtual ~TZStack(void);
	virtual System::_di_IInterface __fastcall Clone();
	virtual AnsiString __fastcall ToString();
	System::_di_IInterface __fastcall Peek();
	System::_di_IInterface __fastcall Pop();
	void __fastcall Push(System::_di_IInterface Value);
	int __fastcall GetCount(void);
	__property int Count = {read=GetCount, nodefault};
private:
	void *__IZStack;	/* Zclasses::IZStack */
	
public:
	operator IZClonnable*(void) { return (IZClonnable*)&__IZStack; }
	operator IZStack*(void) { return (IZStack*)&__IZStack; }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Zcollections */
using namespace Zcollections;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ZCollections
