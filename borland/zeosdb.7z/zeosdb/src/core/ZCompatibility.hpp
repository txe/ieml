// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ZCompatibility.pas' rev: 6.00

#ifndef ZCompatibilityHPP
#define ZCompatibilityHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Contnrs.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Zcompatibility
{
//-- type declarations -------------------------------------------------------
typedef DynamicArray<int >  TIntegerDynArray;

typedef DynamicArray<unsigned >  TCardinalDynArray;

typedef DynamicArray<Word >  TWordDynArray;

typedef DynamicArray<short >  TSmallIntDynArray;

typedef DynamicArray<Byte >  TByteDynArray;

typedef DynamicArray<Shortint >  TShortIntDynArray;

typedef DynamicArray<__int64 >  TInt64DynArray;

typedef DynamicArray<unsigned >  TLongWordDynArray;

typedef DynamicArray<float >  TSingleDynArray;

typedef DynamicArray<double >  TDoubleDynArray;

typedef DynamicArray<bool >  TBooleanDynArray;

typedef DynamicArray<AnsiString >  TStringDynArray;

typedef DynamicArray<WideString >  TWideStringDynArray;

typedef DynamicArray<Variant >  TVariantDynArray;

typedef DynamicArray<System::TObject* >  TObjectDynArray;

typedef int IntegerArray[251658240];

typedef int *PIntegerArray;

typedef void * *PPointer;

typedef Byte *PByte;

typedef bool *PBoolean;

typedef Shortint *PShortInt;

typedef short *PSmallInt;

typedef int *PInteger;

typedef int *PLongInt;

typedef float *PSingle;

typedef double *PDouble;

typedef Word *PWord;

typedef Word *PWordBool;

typedef unsigned *PCardinal;

typedef __int64 *PInt64;

;

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Zcompatibility */
using namespace Zcompatibility;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ZCompatibility
