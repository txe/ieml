// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ZDbcAdoResultSet.pas' rev: 6.00

#ifndef ZDbcAdoResultSetHPP
#define ZDbcAdoResultSetHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ZPlainAdo.hpp>	// Pascal unit
#include <ZPlainAdoDriver.hpp>	// Pascal unit
#include <ZDbcAdo.hpp>	// Pascal unit
#include <ZCompatibility.hpp>	// Pascal unit
#include <ZDbcResultSetMetadata.hpp>	// Pascal unit
#include <ZDbcResultSet.hpp>	// Pascal unit
#include <ZDbcCache.hpp>	// Pascal unit
#include <ZDbcCachedResultSet.hpp>	// Pascal unit
#include <ZDbcGenericResolver.hpp>	// Pascal unit
#include <ZDbcIntfs.hpp>	// Pascal unit
#include <ZCollections.hpp>	// Pascal unit
#include <ZSysUtils.hpp>	// Pascal unit
#include <ZClasses.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <DateUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Zdbcadoresultset
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TZAdoResultSet;
class PASCALIMPLEMENTATION TZAdoResultSet : public Zdbcresultset::TZAbstractResultSet 
{
	typedef Zdbcresultset::TZAbstractResultSet inherited;
	
private:
	DynamicArray<int >  AdoColTypeCache;
	int AdoColumnCount;
	bool FFirstFetch;
	
protected:
	Zplainado::_di_Recordset15 FAdoRecordSet;
	virtual void __fastcall Open(void);
	
public:
	__fastcall TZAdoResultSet(Zdbcintfs::_di_IZStatement Statement, AnsiString SQL, Zplainado::_di_Recordset15 AdoRecordSet);
	__fastcall virtual ~TZAdoResultSet(void);
	virtual void __fastcall Close(void);
	virtual bool __fastcall Next(void);
	virtual bool __fastcall MoveAbsolute(int Row);
	virtual int __fastcall GetRow(void);
	virtual bool __fastcall IsNull(int ColumnIndex);
	virtual AnsiString __fastcall GetString(int ColumnIndex);
	virtual WideString __fastcall GetUnicodeString(int ColumnIndex);
	virtual bool __fastcall GetBoolean(int ColumnIndex);
	virtual Shortint __fastcall GetByte(int ColumnIndex);
	virtual short __fastcall GetShort(int ColumnIndex);
	virtual int __fastcall GetInt(int ColumnIndex);
	virtual __int64 __fastcall GetLong(int ColumnIndex);
	virtual float __fastcall GetFloat(int ColumnIndex);
	virtual double __fastcall GetDouble(int ColumnIndex);
	virtual Extended __fastcall GetBigDecimal(int ColumnIndex);
	virtual Zcompatibility::TByteDynArray __fastcall GetBytes(int ColumnIndex);
	virtual System::TDateTime __fastcall GetDate(int ColumnIndex);
	virtual System::TDateTime __fastcall GetTime(int ColumnIndex);
	virtual System::TDateTime __fastcall GetTimestamp(int ColumnIndex);
	virtual Zdbcintfs::_di_IZBlob __fastcall GetBlob(int ColumnIndex);
};


class DELPHICLASS TZAdoCachedResolver;
class PASCALIMPLEMENTATION TZAdoCachedResolver : public Zdbcgenericresolver::TZGenericCachedResolver 
{
	typedef Zdbcgenericresolver::TZGenericCachedResolver inherited;
	
private:
	Zplainado::_di__Command FHandle;
	int FAutoColumnIndex;
	
public:
	__fastcall TZAdoCachedResolver(Zplainado::_di_Connection15 Handle, Zdbcintfs::_di_IZStatement Statement, Zdbcintfs::_di_IZResultSetMetadata Metadata);
	virtual void __fastcall PostUpdates(Zdbccachedresultset::_di_IZCachedResultSet Sender, Zdbccache::TZRowUpdateType UpdateType, Zdbccache::TZRowAccessor* OldRowAccessor, Zdbccache::TZRowAccessor* NewRowAccessor);
public:
	#pragma option push -w-inl
	/* TZGenericCachedResolver.Destroy */ inline __fastcall virtual ~TZAdoCachedResolver(void) { }
	#pragma option pop
	
private:
	void *__IZCachedResolver;	/* Zdbccachedresultset::IZCachedResolver */
	
public:
	operator IZCachedResolver*(void) { return (IZCachedResolver*)&__IZCachedResolver; }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Zdbcadoresultset */
using namespace Zdbcadoresultset;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ZDbcAdoResultSet
