// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ZComponentReg.pas' rev: 6.00

#ifndef ZComponentRegHPP
#define ZComponentRegHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Zcomponentreg
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
#define ZEOS_DB_PALETTE "Zeos Access"
extern PACKAGE void __fastcall Register(void);

}	/* namespace Zcomponentreg */
using namespace Zcomponentreg;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ZComponentReg
